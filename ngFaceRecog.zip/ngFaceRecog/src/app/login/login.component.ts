import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ProjectDataService } from '../Services/project.service';

@Component({
  selector: 'login-App',
  templateUrl: './login.component.html',
  providers: [ProjectDataService]
})

export class loginComponent {
  strUser: string;
  uname: string;
  psw: string;
  constructor(private _router: Router, public _ProjectDataService: ProjectDataService) {
  }

  OnClick() {
    debugger;

    this._router.navigate(['dashboard']);
    //this._ProjectDataService.getLoginDetail(this.uname, this.psw).subscribe(
    //  result => {
    //    debugger;
    //    this.strUser = JSON.parse(result[0].jsonString)[0];
    //    localStorage.setItem('LoginUser', JSON.parse(result[0].jsonString)[0].LoginCode);
    //    this._router.navigate(['dashboard']);
    //    return;
    //  }, error => {
    //    throw error;
    //  });
    //if (this.strUser == null)
    //  alert("Invalid User");

  }
 
}
