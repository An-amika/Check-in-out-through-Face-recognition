import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RequestOptions } from '@angular/http';
import { Md5 } from 'ts-md5/dist/md5';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  constructor(private commonService: CommonService) { }
  SaveEmployee(employee: any){
    debugger
    let inputvalue = { employee };
    console.log(inputvalue)
    return this.commonService.PostObservable<any, any>('EmployeeSave',inputvalue)
  }
  getEmployee(loginUser: any){
    debugger
    let inputvalue = { loginUser };
    console.log(inputvalue)
    return this.commonService.PostObservable<any, any>('GetEmployee',inputvalue)
  }
  SaveEmployeeTime(employee: any){
    debugger
    let inputvalue = { employee };
    console.log(inputvalue)
    return this.commonService.PostObservable<any, any>('EmployeeTimeSave',inputvalue)
  }
  GetEmployeeTimeSheet(loginUser: any) {
    debugger
    let inputvalue = { loginUser };
    console.log(inputvalue)
    return this.commonService.PostObservable<any, any>('GetEmployeeTimeSheet', inputvalue)
  }
  DownloadFile(ImagePath: any) {
    debugger
    let inputvalue = { ImagePath };
    console.log(inputvalue)
    return this.commonService.PostObservable<any, any>('DownloadFile', ImagePath)
  }
}
