import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RequestOptions } from '@angular/http';
import { Md5 } from 'ts-md5/dist/md5';

@Injectable()
export class CommonService {
    baseUrl: string;
    constructor(private http: HttpClient) {
        this.baseUrl = environment.WebApiUrl + '/api/';
    }

    PostPromise<T, K>(serviceName: string, inputValue: T): Promise<K> {
        const origin = this.baseUrl + serviceName;
        const bodyString = JSON.stringify(inputValue);
        console.log(origin);
        console.log(bodyString);
        return this.http.post(origin, bodyString)
            .pipe(map((response: Response) => response as unknown as K))
            .toPromise();
    }

    GetPromise<K>(serviceName: string): Promise<K> {
        const origin = this.baseUrl + serviceName;
        console.log(origin);
        return this.http.get(origin)
            .pipe(map((response: Response) => response as unknown as K))
            .toPromise();
    }

    PostObservable<T, K>(serviceName: string, inputValue: T,isCacheRequired:boolean=false): Observable<K> {
        const origin = this.baseUrl + serviceName;
        const bodyString = JSON.stringify(inputValue);
        const hash = Md5.hashStr(bodyString);
      let headers = new HttpHeaders({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        if(isCacheRequired)
        {
           headers = headers.set('cacheKey', hash.toString());
        }

        console.log(origin);
        console.log(bodyString);
        return this.http.post(origin, bodyString,{headers:headers})
            .pipe(map((response: Response) => response as unknown as K));
    }
  PostObservable1<T, K>(serviceName: string, inputValue: T, isCacheRequired: boolean = false): Observable<K> {
    const origin = this.baseUrl + serviceName;
    const bodyString = JSON.stringify(inputValue);
    const hash = Md5.hashStr(bodyString);
    let headers = new HttpHeaders({ 'Content-Disposition': 'multipart/form-data' }); // ... Set content type to JSON
    if (isCacheRequired) {
      headers = headers.set('cacheKey', hash.toString());
    }

    console.log(origin);
    console.log(bodyString);
    return this.http.post(origin, inputValue, { headers: headers })
      .pipe(map((response: Response) => response as unknown as K));
  }
  
    GetObservable<K>(serviceName: string): Observable<K> {
        const origin = this.baseUrl + serviceName;
        console.log(origin);
        return this.http.get(origin)
            .pipe(map((response: Response) => response as unknown as K));
    }

    GetObservableWithParam<T,K>(serviceName: string,param:T): Observable<K> {
        const origin = this.baseUrl + serviceName;
        // let requestData = new HttpParams()
        // .set("requestData",encodeURIComponent(JSON.stringify(param)))
        let requestData={requestData:JSON.stringify(param)};
        console.log(origin);
        console.log(requestData);
        return this.http.get(origin,{params: requestData})
            .pipe(map((response: Response) => response as unknown as K));
    }
}
