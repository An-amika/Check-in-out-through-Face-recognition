import { Injectable } from '@angular/core';
import { CommonService } from './common.service';
import { Observable } from 'rxjs';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';

@Injectable()
export class ProjectDataService {
  debugger;
    headers: any;
    options: any;
    constructor(private commonService: CommonService) { }

  getLoginDetail(loginCode: string, passward: string) {
    debugger;
    let inputvalue = { loginCode, passward };
    return this.commonService.PostObservable<any, any>('getLoginDetail', inputvalue);
  }
  UploadFile(file: any) {
    debugger;
   // let inputvalue = { file, Iname };
    return this.commonService.PostObservable1<any, any>('UploadFile', file);
  }
  FindSimilar(sourceImageFileName: string, loginUser: string) {
    debugger;
    let inputvalue = { sourceImageFileName, loginUser };
    return this.commonService.PostObservable<any, any>('FindSimilar', inputvalue);
  }
  FaceAttribute(sourceImageFileName: any) {
    debugger;
    let inputvalue = { sourceImageFileName };
    return this.commonService.PostObservable1<any, any>('FaceAttribute', inputvalue);
  }
}
