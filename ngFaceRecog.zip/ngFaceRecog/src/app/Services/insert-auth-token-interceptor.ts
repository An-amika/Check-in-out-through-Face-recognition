import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { mergeMap } from 'rxjs/operators';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { Md5 } from 'ts-md5/dist/md5';
import { NEVER } from 'rxjs';

@Injectable()
export class InsertAuthTokenInterceptor implements HttpInterceptor {

    constructor(){}
    
    intercept(req: HttpRequest<any>, next: HttpHandler) {
        
         
         const authorizedRequest = req.clone({
             setHeaders: {
                
                 'Content-Type': 'application/json',
             }
         });
         return next.handle(authorizedRequest);

       
    }
}
