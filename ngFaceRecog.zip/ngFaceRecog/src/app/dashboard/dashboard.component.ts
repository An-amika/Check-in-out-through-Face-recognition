import { OnDestroy, Component, ViewChild, OnInit, ViewContainerRef, ComponentFactoryResolver } from '@angular/core';
import { Router } from '@angular/router';
import { GlobalService} from '../Services/global.service';
import * as XLSX from 'xlsx';
import { Subscription, Subject, Observable } from 'rxjs';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { ProjectDataService } from '../Services/project.service';
import { HttpClient, HttpErrorResponse, HttpEventType, HttpRequest } from '@angular/common/http';
import { Filename } from '../Model/project.model';
import { Guid } from '../Services/global.service';

@Component({
    selector: 'dashboard-page',
    templateUrl: './dashboard.component.html'
    , providers: []
})

export class DashboardComponent {
  uname: string;
  // toggle webcam on/off
  public showWebcam = true;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public fl: Filename = new Filename();
  public id: Guid;
  public ImageId: string;

  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];

  // latest snapshot
  public webcamImage: WebcamImage = null;

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();
    progress: number;
    message: string;
    onUploadFinished: any;
     

  public ngOnInit(): void {
    debugger;
   
    WebcamUtil.getAvailableVideoInputs()
      .then((mediaDevices: MediaDeviceInfo[]) => {
        this.multipleWebcamsAvailable = mediaDevices && mediaDevices.length > 1;
      });
  }

  public triggerSnapshot(): void {
    debugger;
    const constraints = {
      'video': true
    }
    navigator.mediaDevices.getUserMedia(constraints)
      .then(stream => {
        debugger;
        console.log('Got MediaStream:', stream);
      })
      .catch(error => {
        console.log('Error accessing media devices.', error);
      });
    //WUakacDy6TKecB532ppub5bSgktybiFHln49
    this.trigger.next();
  }

  public toggleWebcam(): void {
    this.showWebcam = !this.showWebcam;
  }

  public handleInitError(error: WebcamInitError): void {
    this.errors.push(error);
  }

  public showNextWebcam(directionOrDeviceId: boolean | string): void {
   this.nextWebcam.next(directionOrDeviceId);
  }
 
  public handleImage(webcamImage: WebcamImage, event: any): void {
    debugger;
    this.webcamImage = webcamImage;

    const base64 = event.imageAsBase64;

    //this.fl.imagename = "ank.png";
    this.id = Guid.newGuid();
    this.ImageId = this.id + '.' + 'jpg';
    const imageName = this.id + '.' + 'jpg';
    const imageBlob = this.dataURItoBlob(base64);
    const imageFile = new File([imageBlob], imageName, { type: 'image/png' });
    let fileToUpload = imageFile;
    const formData = new FormData();
    formData.append('file', fileToUpload);

    this._ProjectDataService.UploadFile(formData).subscribe(
      result => {
        debugger;
        var status = JSON.parse(result[0].jsonString)[0];

        return;
      }, error => {
        throw error;
    });
    localStorage.setItem('ImageId', this.ImageId);
  }
  dataURItoBlob(dataURI) {
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
      int8Array[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([int8Array], { type: 'image/png' });
    return blob;
  }
  public cameraWasSwitched(deviceId: string): void {
    console.log('active device: ' + deviceId);
    this.deviceId = deviceId;
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public get nextWebcamObservable(): Observable<boolean | string> {
    return this.nextWebcam.asObservable();
  }

  constructor(private _router: Router, public _ProjectDataService: ProjectDataService, private http: HttpClient) { }
  GoToHome() {
    this._router.navigate(['dashboard']);
  }
  GoToEmployeeDetails() {
  //  this._router.navigate(['EmployeeDetails']);
  }
  GoToLogin() {
    this._router.navigate(['login']);
  }
  GoToFillTimeSheet() {
  //  this._router.navigate(['FillTimeSheet']);
  }
  GoToApproveTimeSheet() {
  //  this._router.navigate(['ApproveTimeSheet']);
  }
  public VerifyUser(): void {
    debugger;
    document.getElementById("divLoading").style.visibility = "visible";
    this.triggerSnapshot()
    const loginUser = this.uname;
    localStorage.setItem('LoginUser', this.uname);
      //localStorage.getItem('LoginUser');
    this._ProjectDataService.FindSimilar(this.ImageId, loginUser).subscribe(
      result => {
        debugger;
        alert("Great!! your Face has been Suceessfully Validated.\n\nNow redirecting to Auto System Check-in/out.")
        
        this._router.navigate(['FillTimeSheet']);
       /* var status = JSON.parse(result[0].jsonString)[0];*/

        //localStorage.setItem('LoginUser', JSON.parse(result[0].jsonString)[0].LoginCode);
        //this._router.navigate(['dashboard']);
        return;
      }, error => {
        alert("Sorry.. your face could not been recognized.\n\nPlease register yourself as 1st time user.")
       this._router.navigate(['EmployeeDetails']);
      });
  }
}


