import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { loginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard//dashboard.component';
import { ContentComponent } from './content/content.component';
import { EmployeeDetailsComponent } from './EmployeeDetails/EmployeeDetails.component';
import { FillTimeSheetComponent } from './FillTimeSheet/FillTimeSheet.component';



const appRoutes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  //{ path: 'login', component: loginComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'EmployeeDetails', component: EmployeeDetailsComponent },
  { path: 'FillTimeSheet', component: FillTimeSheetComponent},
  { path: 'ApproveTimeSheet', loadChildren: () => import('./ApproveTimeSheet/ApproveTimeSheet.module').then(mod => mod.ApproveTimeSheetModule) },
  { path: 'Content', component: ContentComponent },
  { path: '**', redirectTo: '/pagenotfound', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
