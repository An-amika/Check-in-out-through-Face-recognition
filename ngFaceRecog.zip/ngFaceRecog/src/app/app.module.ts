import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { MsAdalAngular6Module } from 'microsoft-adal-angular6';
import { environment } from '../environments/environment';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { InsertAuthTokenInterceptor } from './Services/insert-auth-token-interceptor';
//All routing 
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
//All Component 
import { loginComponent } from './login/login.component';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import { CommonService } from './Services/common.service';
import { CookieService } from 'ngx-cookie-service';

import { Md5 } from 'ts-md5/dist/md5';
import { WebcamModule } from 'ngx-webcam';
import { ContentComponent } from './content/content.component';
import { ProjectDataService } from './Services/project.service';
import { EmployeeDetailsComponent } from './EmployeeDetails/EmployeeDetails.component';
import { FillTimeSheetComponent } from './FillTimeSheet/FillTimeSheet.component';
import { GlobalService } from './Services/global.service';

@NgModule({
  imports: [BrowserModule, FormsModule, RouterModule, BrowserAnimationsModule,
    ReactiveFormsModule, AppRoutingModule,
    HttpClientModule, WebcamModule
   ],
  declarations: [AppComponent, DashboardComponent,
    loginComponent, ContentComponent, EmployeeDetailsComponent, FillTimeSheetComponent
  ],
  bootstrap: [AppComponent],
  providers: [HttpModule, CommonService, Md5, CookieService, ProjectDataService, GlobalService 
    
  ],
  entryComponents: []
})

export class AppModule {
}
