import { Component, OnInit } from '@angular/core';
import { FormBuilder,NgForm,FormGroup,FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {EmployeeServiceService } from'../Services/employee-service.service'
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { ProjectDataService } from '../Services/project.service';
import { HttpClient, HttpErrorResponse, HttpEventType, HttpRequest } from '@angular/common/http';
import { Filename } from '../Model/project.model';
import { Subscription, Subject, Observable } from 'rxjs';
import { Guid } from '../Services/global.service';
@Component({
  selector: 'FillTimeSheet-App',
  templateUrl: './FillTimeSheet.component.html'
})

export class FillTimeSheetComponent implements OnInit {
  // toggle webcam on/off
  employeeForm: FormGroup
  IsSaveRecord: boolean = false;
  public showWebcam = true;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public fl: Filename = new Filename();
  public id: Guid;
  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];

  // latest snapshot
  public webcamImage: WebcamImage = null;

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();
  progress: number;
  message: string;
  onUploadFinished: any;
  constructor(private _router: Router ,  public _ProjectDataService: ProjectDataService, private http: HttpClient, private _fb: FormBuilder,
    private _empService: EmployeeServiceService) {
    this.id = Guid.newGuid();

this.employeeForm = this._fb.group({
  EmployeeName:[''],
  EmployeeCode:[''],
  Mobile:[''],
  ManagerCode:[''],
  LoginTime:[new Date()],
  image: this.id + '.' + 'jpg',
})
   }
      GoToHome() {
        this._router.navigate(['dashboard']);
      }
      GoToEmployeeDetails() {
       // this._router.navigate(['EmployeeDetails']);
      }
      GoToLogin() {
       // this._router.navigate(['login']);
      }
  GoToFillTimeSheet() {
    this._router.navigate(['FillTimeSheet']);
  }
  GoToApproveTimeSheet() {
    this._router.navigate(['ApproveTimeSheet']);
  }
      ngOnInit(){
        this.getEmployee();
        WebcamUtil.getAvailableVideoInputs()
          .then((mediaDevices: MediaDeviceInfo[]) => {
            this.multipleWebcamsAvailable = mediaDevices && mediaDevices.length > 1;
          });
      }
      getEmployee(){
        const loginUser = localStorage.getItem('LoginUser');
        this._empService.getEmployee(loginUser).subscribe(res =>{
         const results = JSON.parse(res[0].jsonString)[0]
         this.employeeForm.controls.EmployeeName.patchValue(results.EmployeeName)
         this.employeeForm.controls.EmployeeCode.patchValue(results.EmployeeCode)
         this.employeeForm.controls.Mobile.patchValue(results.Mobile)
         this.employeeForm.controls.ManagerCode.patchValue(results.ManagerCode)
         this.employeeForm.controls.LoginTime.patchValue(new Date().toLocaleDateString()+' ' + new Date().toLocaleTimeString())
      console.log(results);
        });
      }
save(){
  debugger
  this.triggerSnapshot();
//  console.log(this.employeeForm.value);
//  this._empService.SaveEmployeeTime(this.employeeForm.value).subscribe(res =>{
//    if(res ===true){
//      this.IsSaveRecord = true;
//    }
//    this.employeeForm.reset();
//console.log(res);
//  });
}

  public triggerSnapshot(): void {
    debugger;
    const constraints = {
      'video': true
    }
    navigator.mediaDevices.getUserMedia(constraints)
      .then(stream => {
        debugger;
        console.log('Got MediaStream:', stream);
      })
      .catch(error => {
        console.log('Error accessing media devices.', error);
      });
    //WUakacDy6TKecB532ppub5bSgktybiFHln49
    this.trigger.next();
  }

  public toggleWebcam(): void {
    this.showWebcam = !this.showWebcam;
  }

  public handleInitError(error: WebcamInitError): void {
    this.errors.push(error);
  }

  public showNextWebcam(directionOrDeviceId: boolean | string): void {
    this.nextWebcam.next(directionOrDeviceId);
  }

  public handleImage(event: any): void {
    debugger;
    const base64 = event.imageAsBase64;

    //this.fl.imagename = "ank.png";
    const imageName = this.id + '.' + 'jpg';
    const imageBlob = this.dataURItoBlob(base64);
    const imageFile = new File([imageBlob], imageName, { type: 'image/png' });
    let fileToUpload = imageFile;
    const formData = new FormData();
    formData.append('file', fileToUpload);

    this._ProjectDataService.UploadFile(formData).subscribe(
      result => {
        debugger;
        var status = JSON.parse(result[0].jsonString)[0];

        return;
      }, error => {
        throw error;
      });
    console.log(this.employeeForm.value);
    console.log(this.employeeForm.value);
    this._empService.SaveEmployeeTime(this.employeeForm.value).subscribe(res => {
      if (res === true) {
        this.IsSaveRecord = true;
      }
      this.employeeForm.reset();
      console.log(res);
    });
    this._router.navigate(['ApproveTimeSheet']);
    //console.info('received webcam image', event);
    //this.webcamImage = webcamImage;
  }
  dataURItoBlob(dataURI) {
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
      int8Array[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([int8Array], { type: 'image/png' });
    return blob;
  }
  public cameraWasSwitched(deviceId: string): void {
    console.log('active device: ' + deviceId);
    this.deviceId = deviceId;
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public get nextWebcamObservable(): Observable<boolean | string> {
    return this.nextWebcam.asObservable();
  }
}
