import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'; 
import { ApproveTimeSheetRoutingModule } from './ApproveTimeSheet-routing.module';
 
@NgModule({
  imports: [CommonModule, ApproveTimeSheetRoutingModule, FormsModule, ReactiveFormsModule, NgbModule],
  declarations: [ApproveTimeSheetRoutingModule.components],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
  
})
export class ApproveTimeSheetModule {

}
