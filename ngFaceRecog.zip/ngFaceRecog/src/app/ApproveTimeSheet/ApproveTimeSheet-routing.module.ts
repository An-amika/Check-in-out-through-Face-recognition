import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApproveTimeSheetComponent } from './ApproveTimeSheet.component';

const appRoutes: Routes = [
    {
    path: '', component: ApproveTimeSheetComponent,
        children: [
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(appRoutes)],
    exports: [RouterModule]
})
export class ApproveTimeSheetRoutingModule {
  static components = [ApproveTimeSheetComponent];
}
