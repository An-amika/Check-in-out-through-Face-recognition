import { Component, OnInit } from '@angular/core';
import { FormBuilder,NgForm,FormGroup,FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {EmployeeServiceService } from'../Services/employee-service.service'
import { ProjectDataService } from '../Services/project.service';

@Component({
  selector: 'ApproveTimeSheet-App',
  templateUrl: './ApproveTimeSheet.component.html'
})

export class ApproveTimeSheetComponent implements OnInit {
  employeeForm:FormGroup
  IsSaveRecord: boolean = false;
    results: any;
  constructor(private _router: Router , private _fb:FormBuilder , 
    private _empService: EmployeeServiceService ) {
this.employeeForm = this._fb.group({
  EmployeeName:[''],
  EmployeeCode:[''],
  Mobile:[''],
  ManagerCode:[''],

})
   }
      GoToHome() {
        this._router.navigate(['dashboard']);
      }
      GoToEmployeeDetails() {
        this._router.navigate(['EmployeeDetails']);
      }
      GoToLogin() {
        this._router.navigate(['login']);
      }
  GoToFillTimeSheet() {
    this._router.navigate(['FillTimeSheet']);
  }
  GoToApproveTimeSheet() {
    this._router.navigate(['ApproveTimeSheet']);
  }
 
      ngOnInit(){
        this.getEmployeeTimeSheet();

      }
  getEmployeeTimeSheet() {
    debugger;
    const loginUser = localStorage.getItem('LoginUser');
    this._empService.GetEmployeeTimeSheet(loginUser).subscribe(res => {
      this.results = JSON.parse(res[0].jsonString)
      console.log(this.results);
    });
  }
save(){
  debugger  
  console.log(this.employeeForm.value);
  this._empService.SaveEmployee(this.employeeForm.value).subscribe(res =>{
    if(res ===true){
      this.IsSaveRecord = true;
    }
    this.employeeForm.reset();
console.log(res);
  });
}
}
