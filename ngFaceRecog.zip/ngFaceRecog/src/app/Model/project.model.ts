
export class loaderShow {
    gLob: boolean = false;
    lobs: boolean= false;
    sdu: boolean = false;
    du: boolean = false;
    prj: boolean = false;
    wbs: boolean = false;
    role: boolean = false;
    cpntTyp: boolean = false;
    asgTyps: boolean = false;
}

export class Filename {

  public imagename: string;
  constructor() {
    this.imagename = "";

  }
}
