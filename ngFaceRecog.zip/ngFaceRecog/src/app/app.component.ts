import { Component } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute, ActivationEnd } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  providers:[]
})
export class AppComponent {
  AppComponentLoader = false;
  showHeader = false;
  constructor(private _router: Router) {
    this.getLoginDetails();
  }
  getLoginDetails() {
    this._router.navigate(['login']);
  }
  ngOnInit() {
  }
}
