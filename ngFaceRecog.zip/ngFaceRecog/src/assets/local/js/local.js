function prevTab(elem) {
    $(elem).prev().find('a[data-toggle="tab"]').click();
}

$(document).ready(function () {
    size_li = $("#employee li").size();
    x = 5;
    $('#employee li:lt(' + x + ')').show();
    $('#addMore').click(function () {
        x = (x + 6 <= size_li) ? x + 6 : size_li;
        $('#employee li:lt(' + x + ')').show();
        //$(this).siblings("li").addClass("siblingDivChild");
        $(this).hide();
    });

    //dropshow Show		
    $(".sizevalue").click(function () {
        $(".dropShow").toggle();
    });

    // on click text value input in  input field	
    $('li.srC').on('click', function () {
        var content = $(this).text();
        $('#valueField').val(content);
    });
    //dropshow Hide	 
    $(document).on("click", ".srC", function () {
        $(this).parents(".dropShow").hide();
    });
});

//Outside click dropdown hide
$(document).mouseup(function (e) {
    var container = $(".dropShow");
    if (!container.is(e.target) && container.has(e.target).length === 0) {
        container.hide();
    }
});

// Success Msg
function submitEnableForm(event) {
    $('.splash-screen').removeClass('hide').addClass('show');
    $("#success_model").stop().slideDown();
    $('#success_model').delay(3000).slideUp('500', function () {
        $('.splash-screen').removeClass('show').addClass('hide');
        $(location).attr('href', 'dashboard.html');
    });
    //event.preventDefault();
}

// Elips when width increase then show tooltip
$(document).on('mouseenter', ".elips", function () {
    var $this = $(this);
    if (this.offsetWidth < this.scrollWidth && !$this.attr('title')) {
        $this.tooltip({
            title: $this.text(),
            placement: "auto",
            container:'body'
        });
        $this.tooltip('show');
    }
});


$(document).ready(function () {
    $(".prev-step").click(function (e) {
        var $active = $('.wizard .nav-tabs li.active');
        prevTab($active);
        $(".formSteps li").removeClass('complete');
    });
    $(document).on('mouseover', ".bootstrap-select button", function () {
        //$(this).removeAttr('title');
        $(this).removeClass('btn');
    });

    $(".addBtn").click(function () {
        $(".formSteps li").addClass('complete');
    });
    // Tooltip Hide on click
    $(".elips").click(function () {
        $(this).tooltip('hide');
    });


    //onClick Next & prev Class Add & Remove in employee Lookup

    //$(document).on("click", ".nextBtn, .formSteps li a", function (e) {
    //    alert("HI");
    //    //$(".leftOverlap").addClass("overlapEmploye").css({ "left": "-100%", "border-right": "0", "transition": "all 0s ease-in-out" });
    //    ////$(".widthIncrease").css("width", "100%");
    //    //$(".arrowSlide").css("display", "block");
    //    $(".plus").show();
    //    $(".minus").hide();
    //});

    //$(".nextBtn, .formSteps li a").click(function () {
    //    $(".leftOverlap").addClass("overlapEmploye").css({ "left": "-100%", "border-right": "0", "transition": "all 0s ease-in-out" });
    //    $(".widthIncrease").css("width", "100%");
    //    $(".arrowSlide").css("display", "block");
    //    $(".plus").show();
    //    $(".minus").hide();
    //});

    //$(document).on("click", ".projectDetails", function (e) {
    //    alert("HI1");
    //    //$(".leftOverlap").css({ "left": "0", "border-right": "1px solid #e0e0e0", "transition": "all 0s ease-in-out" });
    //    //$(".leftOverlap").removeClass("overlapEmploye");
    //    //$(".widthIncrease").css("width", "75%");
    //    //$(".arrowSlide").css("display", "none");
    //    //$(".plus").hide();
    //    //$(".minus").show();
    //});

    //$(document).on("click", ".plus", function (e) {
    //    alert("HI2");
    //    $(".plus").hide();
    //    $(".minus").show();
    //    $(this).parents(".formSec").find(".overlapEmploye").css({ "left": "0", "border-right": "1px solid #e0e0e0", "box-shadow": "0px 0px 9px 3px rgba(13,86,98,0.08)", "transition": "all 0.3s ease-in-out" });

    //});
    //$(document).on("click", ".minus", function (e) {
    //    alert("HI3");
    //    $(".plus").show();
    //    $(".minus").hide();
    //    $(this).parents(".formSec").find(".overlapEmploye").css({ "left": "-100%", "border-right": "0", "box-shadow": "none" });
    //});

    // final submit	
    $("#submit").click(function () {
        submitEnableForm();
    });



    $("#cancels").on("click", function () {
        $("#updtaedEmployee").hide();
        $("#projectSummary").show();
    });
    //onCLick Option new page load	
    /*$("#bulkAction").change(function(){
        document.location.href = $(this).val();
    });*/

    //Employee lookup delete icon js
    $(".delete i").on("click", function () {
        $(".empList .showCheckBox input:checked").parents("li").remove();
    });
    // Updtaed Employee Show
    $("#applyBtn button, #SearchBtn").on("click", function () {
        $("#updtaedEmployee").show();
        $("#projectSummary").hide();
    });

    //Employee lookup Search predective
    $("#search").keyup(function () {
        var searchText = $(this).val().toLowerCase();
        $.each($(".empList li"), function () {
            if ($(this).text().toLowerCase().indexOf(searchText) === -1)
                $(this).hide();
            else
                $(this).show();
        });
    });

    $("#deployedJob").keyup(function () {
        var searchText = $(this).val().toLowerCase();
        $.each($(".srC"), function () {
            if ($(this).text().toLowerCase().indexOf(searchText) === -1)
                $(this).hide();
            else
                $(this).show();
            $("#addMore").hide();
        });
    });

    // Project Sumarry scroll top to bottom and bottom to top Js
    //$(document).on("click", ".addBtn", function () {
    //    $('html, body').animate({
    //        scrollTop: $("#projectSummary").offset().top
    //    }, 1000);
    //});

    //$(document).on("click", ".editIcon", function () {
    //    $('html, body').animate({
    //        scrollTop: $("body").offset().top
    //    }, 500);
    //});

    // Project Sumarry delete functionality
    $(".deleteIcon").on("click", function () {
        $(".projectSummary .showCheckBox input:checked").parents("tr").remove();
    });


    // family Job

    /*$("select").click(function(){
        $(".dropShow").hide();
    });
        
    $(document).on("click", "li.siblingDivChild" , function() {
        $(this).parents(".firstUl").hide();
        $(".siblingDiv").toggle();
    });
    $("#sizelist").on("click", "a", function(e){
        //e.preventDefault();
        var $this = $(this).parent();
        $this.addClass("select").siblings().removeClass("select");
        $("#sizevalue").val($this.data("value"));
        $(this).parents(".dropShow, .siblingDiv").hide();
        $(this).parents(".errorClass").removeClass("has-error");
    });
    $("#employee").on("click", "a", function(e){
        //e.preventDefault();
        var $this = $(this).parent();
        $this.addClass("select").siblings().removeClass("select");
        $("#sizevalue1").val($this.data("value"));
    });*/


    // Custom Scroll
    $(".empList, .jobScroll, .errorText").mCustomScrollbar({
        theme: "dark-thin"
    });


    $(".assignTableScroll").mCustomScrollbar({
        axis: "yx",
        theme: "light-3",
        advanced: { autoExpandHorizontalScroll: true }
    });

    // Floating Label 
    $('.inputMaterial').on('focus blur', function (e) {
        $(this).parent('.input-field').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
    }).trigger('blur');


    // Error Hover Js for Validate Page
    //$(".topRightArrow").hover(function (e) {
    //    e.preventDefault();
    //    e.stopPropagation();
    //    $(".Not_Editable").css({ 'opacity': '0', 'visibility': 'hidden' });
    //    $(this).parent(".hoverSec").find(".Not_Editable").css({ 'opacity': '1', 'visibility': 'visible' });
    //});

    //$(".Not_Editable").hover(function (e) {alert
    //    e.stopPropagation();
    //});
    //$(".projectSummary, .validateCheck, tbody tr, .main-body, body").hover(function () {
    //    $(".Not_Editable").css({ 'opacity': '0', 'visibility': 'hidden' });
    //});
    //$(".projectSummary, .validateCheck, tbody tr, .main-body, body").click(function () {
    //    $(".Not_Editable").css({ 'opacity': '0', 'visibility': 'hidden' });
    //});

    //DtaePIcker
    $('.date_list1').datepicker({
        format: "dd MMyy",
        orientation: 'auto right',
        autoclose: true,
        forceParse: false,
        ignoreReadonly: false
    }).on('change', function () {
        $('.datepicker').hide();
        $(this).parents('.errorClass').removeClass('has-error');
    });

    // Popover code start here
    $('.pop-action').popover({
        content: $('#infoProject').html(),
        trigger: 'hover',
        placement: 'auto',
        html: true,
        container: 'body',
    }).on('mouseenter', function () {
        $('.popover').addClass("usdDetail");
    });

    //Map Popover
    $('.addMap').popover({
        content: $('#mapDetail').html(),
        trigger: 'hover',
        placement: 'auto',
        html: true,
        container: 'body',
    }).on('mouseenter', function () {
        $('.popover').addClass("mapDetail");
        //$('.addMap').not(this).popover('hide');
    });

    /*$('html').on('click', function(e) {
      if (typeof $(e.target).data('original-title') == 'undefined' &&
         !$(e.target).parents().is('.popover.in')) {
        $('[data-original-title]').popover('hide');
      }
    });*/

    $('.delimitPop').popover({
        content: $('#delimitDetail').html(),
        trigger: 'hover',
        placement: 'auto',
        html: true,
        container: 'body',
    }).on('mouseenter', function () {
        $('.popover').addClass("mapDetail");
        //$('.addMap').not(this).popover('hide');
    });


    //error Popover
    $('.errorPopover').popover({
        content: $('#errorList').html(),
        trigger: 'hover',
        placement: 'auto',
        html: true,
        container: 'body',
    }).on('mouseenter', function () {
        $('.popover').addClass("errorList");
    });

    // Project	Deployed Job Js in Project Form page
    $(".deployedJob").on("change", function () {
        $(this.value == "");
        $("#job").show();
        $(".deployedJob").hide();
    });

    $(window).load(function () {
        $('.multiselect-selected-text').html('Select');
    });

    //update assignation radio btn click html show
    $('.stausAssign input').on('change', function () {
        $("#" + this.value).show().siblings('.report').hide();
        if ($(this).val() === "sync") {
            $("#search").click(function () {
                $(location).attr('href', 'proposedScreen.html');
            });
        } else if ($(this).val() === "proposed") {
            $("#search").click(function () {
                $(location).attr('href', 'proposedData.html');
            });
        }

    });

    // onClick AddDelimit sibling button remove attr
    $("#addDelimit").on("click", function () {
        $("#createAssign").removeAttr('disabled');
    });

    // In Proposed Screen on checked input then disabled & enable apply btn
    $('.check1, .checkAll1').change(function () {
        if (true === $(this).prop('checked')) {
            $('.applyBTn').removeClass('disabledDiv');
        }
        if ($('.check1:not(:checked)').length === $('.check1').length) {
            $('.applyBTn').addClass('disabledDiv');
        }
    });
    // In Proposed Screen on checked radio then disabled & enable apply btn
    $(".radioCheck").change(function () {
        $('.applyBTn').removeClass('disabledDiv');
    });

    //Add Delimit New Assignation tr show & hide
    $("#addBtn").on("click", function () {
        $("#addAssign").css('display', 'block');
    });
    //Add Delimit New Assignation tr show & hide End



    //Add Delimit New Assignation tr show & hide End

    $('.collapse').on('shown.bs.collapse', function () {
        $(this).parent().find(".icon-plus").removeClass("icon-plus").addClass("icon-minus");
    }).on('hidden.bs.collapse', function () {
        $(this).parent().find(".icon-minus").removeClass("icon-minus").addClass("icon-plus");
    });


}); // Document ready End
