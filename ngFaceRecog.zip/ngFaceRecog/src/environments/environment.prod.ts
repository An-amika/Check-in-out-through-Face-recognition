export const environment = {
  production: true,
  tenant: '',
  clientId: '',
  redirectUri: '',
  endpoints: {
    '': '',
  },
  navigateToLoginRequestUrl: false,
  cacheLocation: 'localStorage',
  appInsightsKey: '',
  WebApiUrl: '',
  resourceScopes: ''
};
