export const environment = {
  tenant: '',
  clientId: '',
  production: false,
  redirectUri: 'http://localhost:4406/',
  navigateToLoginRequestUrl: false,
  cacheLocation: 'localStorage',
  WebApiUrl:'http://localhost:40104',
  resourceScopes: '',
  endpoint:'https://westcentralus.api.cognitive.microsoft.com/face/v1.0/detect',
};
