﻿namespace FACERecog.API.Entity
{
    public class resultJson
    {
        public int id { get; set; }
        public string JsonString { get; set; }
        public string Status { get; set; }
    }
}
