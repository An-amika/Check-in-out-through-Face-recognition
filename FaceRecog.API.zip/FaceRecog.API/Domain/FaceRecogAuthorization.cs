﻿using FACERecog.API.Contracts;
using FACERecog.API.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;

namespace FACERecog.API.Domain
{
    public class FACERecogAuthorization : IFACERecogAuthorization
    {
        private readonly IBaseRepository _baseRepository;

        public FACERecogAuthorization(IBaseRepository baseRepository)
        {
            _baseRepository = baseRepository;
        }


        public async Task<IEnumerable<resultJson>> getLoginDetail(string value)
        {
            var result= await _baseRepository.ExecuteQuery("az_USP_FACERecog_getLoginDetails", value);
            return result;
        }

        public async Task<IEnumerable<resultJson>> SaveEmployee(string jsonInput)
        {
            var result = await _baseRepository.ExecuteQuery("az_USP_FACERecog_SaveEmployee", jsonInput);
            return result;
        }
        public async Task<IEnumerable<resultJson>> GetEmployee(string jsonInput)
        {
            var result = await _baseRepository.ExecuteQuery("az_USP_FACERecog_GetEmployee", jsonInput);
            return result;
        }
        public async Task<IEnumerable<resultJson>> EmployeeTimeSave(string jsonInput)
        {
            var result = await _baseRepository.ExecuteQuery("az_USP_FACERecog_SaveEmployeeTime", jsonInput);
            return result;
        }
        public async Task<IEnumerable<resultJson>> GetEmployeeTimeSheet(string jsonInput)
        {
            var result = await _baseRepository.ExecuteQuery("az_USP_FACERecog_GetEmployeeTimeSheet", jsonInput);
            return result;
        }
        public async Task<IEnumerable<resultJson>> GetEmployeeImage(string jsonInput)
        {
            var result = await _baseRepository.ExecuteQuery("az_USP_FACERecog_GetEmployeeImage", jsonInput);
            return result;
        }
    }
}
