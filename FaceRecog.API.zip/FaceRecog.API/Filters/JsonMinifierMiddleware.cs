﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
namespace FACERecog.API.Filters
{
    class OptFields
    {
        public String PopertyName { get; set; }
        public String Abreviation { get; set; }
    }
    class Root{
        public List<Dictionary<string, object>> Data { get; set; }
    }
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class JsonMinifierMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IWebHostEnvironment _hostingEnvironment;
        public JsonMinifierMiddleware(RequestDelegate next, IWebHostEnvironment hostingEnvironment)
        {
            _next = next; _hostingEnvironment = hostingEnvironment;
        }

        private List<OptFields> GlobalRenamingList()
        {
            string contentRootPath = _hostingEnvironment.ContentRootPath;
            var jsonString = System.IO.File.ReadAllText(contentRootPath + "/OptFields.json");
            List<OptFields> jsonModel = JsonSerializer.Deserialize<List<OptFields>>(jsonString);
            return jsonModel;
        }
        public async Task Invoke(HttpContext context)
        {
               //JObject jsonObj = JObject.Parse(jsonString);
               //await _next(context);
               //await MinifyRequest(context);
               await MinifyResponse(context);
        }

        private async Task MinifyResponse(HttpContext context)
        {
            Stream responseBody = context.Response.Body;
            using (var newResponseBody = new MemoryStream())
            {
                context.Response.Body = newResponseBody;
                await _next(context);
                context.Response.Body = new MemoryStream();
                newResponseBody.Seek(0, SeekOrigin.Begin);
                context.Response.Body = responseBody;
                String JsonResp = new StreamReader(newResponseBody).ReadToEnd();
                if (JsonResp.Trim().Length > 0)
                {
                    String outputResp = JsonResp;
                    var root = Newtonsoft.Json.Linq.JToken.Parse(outputResp);
                    var jkeys = root
                        .SelectMany(t => t.Children().OfType<Newtonsoft.Json.Linq.JProperty>().Select(p => p.Name))
                        .Distinct().ToArray();

                    List<OptFields> fileds = GlobalRenamingList();
                    foreach (var _keys in jkeys)
                    {
                        OptFields _items = fileds.FirstOrDefault(x => x.PopertyName == _keys.ToString());
                        if(_items!=null)
                        outputResp = outputResp.Replace($"\"{_items.PopertyName}\":", $"\"{_items.Abreviation}\":");
                    }
                    await context.Response.WriteAsync(outputResp);
                }
                else
                {
                    await _next(context);
                }
            }
        }

        private async Task MinifyRequest(HttpContext context)
        {
            var request = context.Request;
            context.Request.EnableBuffering();
            // Leave the body open so the next middleware can read it.
            using (var reader = new StreamReader(
                context.Request.Body,
                encoding: Encoding.UTF8,
                detectEncodingFromByteOrderMarks: false,
                bufferSize: -1,
                leaveOpen: true))
            {
                var body = await reader.ReadToEndAsync();
                if (body.Trim().Length > 0)
                {
                    string outputReq = body;
                    if (outputReq.Trim().Length > 0)
                    {
                        foreach (OptFields _items in GlobalRenamingList())
                        {
                            outputReq = outputReq.Replace($"\"{_items.Abreviation}\":", $"\"{_items.PopertyName}\":");
                        }
                    }
                    request.ContentType = "application/json";
                    request.Body = new MemoryStream(Encoding.UTF8.GetBytes(outputReq));
                }
                // Reset the request body stream position so the next middleware can read it
                context.Request.Body.Position = 0;
            }
            await _next.Invoke(context);
        }
    }
}
