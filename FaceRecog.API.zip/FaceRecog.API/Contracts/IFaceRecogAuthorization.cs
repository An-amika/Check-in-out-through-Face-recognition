﻿using FACERecog.API.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;

namespace FACERecog.API.Contracts
{
    public interface IFACERecogAuthorization
    {
        Task<IEnumerable<resultJson>> getLoginDetail(string value);
        Task<IEnumerable<resultJson>> SaveEmployee(string jsonInput);
        Task<IEnumerable<resultJson>> GetEmployee(string jsonInput);
        Task<IEnumerable<resultJson>> EmployeeTimeSave(string jsonInput);
        Task<IEnumerable<resultJson>> GetEmployeeTimeSheet(string jsonInput);
        Task<IEnumerable<resultJson>> GetEmployeeImage(string jsonInput);
    }
}
