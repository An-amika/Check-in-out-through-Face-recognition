﻿using Microsoft.Extensions.Configuration;
using FACERecog.API.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FACERecog.API.Contracts
{
    public interface IBaseRepository
    {
        IConfiguration GetConfiguration();
        Task<IEnumerable<resultJson>> ExecuteQuery(string procName);
        Task<IEnumerable<resultJson>> ExecuteQuery(string procName, string jsonInput);
        Task<IEnumerable<resultJson>> ExecuteQuery(string procName, string jsonInput, int optionalPara);
        Task<object> ExecuteScalar(string procName, string jsonInput);
     }
}
