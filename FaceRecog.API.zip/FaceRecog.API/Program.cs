using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;

namespace FACERecog.API
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }


        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
            .ConfigureLogging(
                    builder =>
                    {
                        builder.Services.Configure<FormOptions>(o =>
                        {
                            o.ValueLengthLimit = int.MaxValue;
                            o.MultipartBodyLengthLimit = int.MaxValue;
                            o.MemoryBufferThreshold = int.MaxValue;
                        });
                    }
                )
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                })
            
        
            ;
        
    }
}
