﻿using Dapper;
using FACERecog.API.Contracts;
using FACERecog.API.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;
using System.Linq;
using Newtonsoft.Json;

namespace FACERecog.API.Repository
{
    public class BaseRepository : IBaseRepository
    {
        private readonly IDbConnection con;
        private readonly string connectionString = "";
        private readonly IConfiguration _configuration;

        public BaseRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            connectionString = Environment.GetEnvironmentVariable("SQLCONNSTR_DbConnectionString");
            con = new SqlConnection(connectionString);
            

        }

        public IConfiguration GetConfiguration() => _configuration;

        public async Task<IEnumerable<resultJson>> ExecuteQuery(string procName)
        {
            var result = await SqlMapper.QueryAsync<resultJson>(con, procName, commandType: CommandType.StoredProcedure);
            return result;
        }

        public async Task<IEnumerable<resultJson>> ExecuteQuery(string procName, string jsonInput)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("JsonString", jsonInput.ToString());
            var result = await SqlMapper.QueryAsync<resultJson>(con, procName, param: parameters, commandTimeout: 5000, commandType: CommandType.StoredProcedure);
            return result; 
        }

        public async Task<object> ExecuteScalar(string procName, string jsonInput)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@JsonString", jsonInput.ToString());
            var result = await SqlMapper.ExecuteScalarAsync<object>(con, procName, param: parameters, commandTimeout: 5000, commandType: CommandType.StoredProcedure);
            return result; 
        }

        public async Task<IEnumerable<resultJson>> ExecuteQuery(string procName, string jsonInput, int mode)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("JsonString", jsonInput.ToString());
            parameters.Add("mode", mode);

            var result = await SqlMapper.QueryAsync<resultJson>(con, procName, param: parameters, commandTimeout: 5000, commandType: CommandType.StoredProcedure);
            return result;  
        }

    }
}