using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using FACERecog.API.Contracts;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.IO;
using System.Net.Http.Headers;
using Microsoft.Azure.CognitiveServices.Vision.Face;
using Microsoft.Azure.CognitiveServices.Vision.Face.Models;
using System.Collections.Generic;
using System;
using System.Linq;

namespace FACERecog.API.Controllers
{
    [ApiController]
    public class AuthorizationController : ControllerBase
    {
        private readonly IFACERecogAuthorization _authorization;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AuthorizationController(IFACERecogAuthorization authorization, IHttpContextAccessor httpContextAccessor)
        {
            _authorization = authorization;
            _httpContextAccessor = httpContextAccessor;
        }

        [Route("api/getLoginDetail"), HttpPost]
        public async Task<IActionResult> getLoginDetail([FromBody] dynamic value)
        {
            var result = await _authorization.getLoginDetail(value.ToString());
            return Ok(result);
        }
        [Route("api/EmployeeSave"), HttpPost]
        public async Task<IActionResult> EmployeeSave([FromBody] dynamic value)
        {
            var result = await _authorization.SaveEmployee(value.ToString());
            return Ok(true);
        }
        [Route("api/GetEmployee"), HttpPost]
        public async Task<IActionResult> GetEmployee([FromBody] dynamic value)
        {
            var result = await _authorization.GetEmployee(value.ToString());
            return Ok(result);
        }
        [Route("api/EmployeeTimeSave"), HttpPost]
        public async Task<IActionResult> EmployeeTimeSave([FromBody] dynamic value)
        {
            var result = await _authorization.EmployeeTimeSave(value.ToString());
            return Ok(result);
        }
        [Route("api/GetEmployeeTimeSheet"), HttpPost]
        public async Task<IActionResult> GetEmployeeTimeSheet([FromBody] dynamic value)
        {
            var result = await _authorization.GetEmployeeTimeSheet(value.ToString());
            return Ok(result);
        }
        [Route("api/UploadFile"), HttpPost]
        public async Task<IActionResult> UploadFile([FromForm(Name = "file")] IFormFile files)
        {
            FileDetails fileDetails;
            using (var reader = new StreamReader(files.OpenReadStream()))
            {
                var fileContent = reader.ReadToEnd();
                var parsedContentDisposition = ContentDispositionHeaderValue.Parse(files.ContentDisposition);
                fileDetails = new FileDetails
                {
                    Filename = files.FileName,
                    Content = fileContent,
                    ContentType = "image/jpg"
                };
            }
            string systemFileName = fileDetails.Filename;

            string blobstorageconnection = "DefaultEndpointsProtocol=https;AccountName=testrasstorage;AccountKey=okpJES79x7HJbFM6m87e6D56YZ+Kv49mtIqPvILVbq6Sv/RK8LeT55FgYeNo6Fm4xUm/9OZqVbR4BBe6A61JnA==;EndpointSuffix=core.windows.net";
            // "https://testrasstorage.blob.core.windows.net";
            //_configuration.GetValue<string>("BlobConnectionString");
            // Retrieve storage account from connection string.    
            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(blobstorageconnection);
            // Create the blob client.    
            CloudBlobClient blobClient = cloudStorageAccount.CreateCloudBlobClient();
            // Retrieve a reference to a container.    
            CloudBlobContainer container = blobClient.GetContainerReference("blobcontainer");
            // This also does not make a service call; it only creates a local object.    
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(systemFileName);

            await using (var data = files.OpenReadStream())
            {
                await blockBlob.UploadFromStreamAsync(data);
            }
            return Ok("File Uploaded Successfully");
        }
        [Route("api/FindSimilar"), HttpPost]
        public async Task<IActionResult> FindSimilar([FromBody] dynamic value)
        {


            var result = await _authorization.GetEmployeeImage(value.ToString());
            //var myJObject = JsonConvert.DeserializeObject<List<Jsonoutput>>(result.ToList()[0].JsonString);
            var str = result[0];
            var myJObject = ((FACERecog.API.Entity.resultJson)str).JsonString;
            var myJObject1 = JsonConvert.DeserializeObject<List<Jsonoutput>>(myJObject);
            //JsonConvert.DeserializeObject<IEnumerable<Jsonoutput>>(myJObject);
            string sourceImageFileName = myJObject1[0].sourceImageFileName;
            string targetImageFile = myJObject1[0].targetImageFile;
            // <snippet_loadfaces>
            //Console.WriteLine("========FIND SIMILAR========");
            //Console.WriteLine();
            const string recognition_model = RecognitionModel.Recognition04;
            const string base_url = "https://testrasstorage.blob.core.windows.net/blobcontainer/";
            const string SUBSCRIPTION_KEY = "5aea0303917e4cf184c0e94c8f8b474e";
            const string ENDPOINT = "https://faceapiresourcedemo20.cognitiveservices.azure.com/";

            IFaceClient client = Authenticate(ENDPOINT, SUBSCRIPTION_KEY);

            List<string> targetImageFileNames = new List<string>
                                    {
                                        targetImageFile,
                                    };

            IList<Guid?> targetFaceIds = new List<Guid?>();
            foreach (var targetImageFileName in targetImageFileNames)
            {
                // Detect faces from target image url.
                var faces = await DetectFaceRecognize(client, $"{base_url}{targetImageFileName}", recognition_model);
                // Add detected faceId to list of GUIDs.
                targetFaceIds.Add(faces[0].FaceId.Value);
            }

            // Detect faces from source image url.
            IList<DetectedFace> detectedFaces = await DetectFaceRecognize(client, $"{base_url}{sourceImageFileName}", recognition_model);
            Console.WriteLine();
            // </snippet_loadfaces>

            // <snippet_find_similar>
            // Find a similar face(s) in the list of IDs. Comapring only the first in list for testing purposes.
            IList<SimilarFace> similarResults = await client.Face.FindSimilarAsync(detectedFaces[0].FaceId.Value, null, null, targetFaceIds);
            // </snippet_find_similar>
            // <snippet_find_similar_print>
            foreach (var similarResult in similarResults)
            {
                return Ok(result);
                //Console.WriteLine($"Faces from {sourceImageFileName} & ID:{similarResult.FaceId} are similar with confidence: {similarResult.Confidence}.");
            }
            return Ok("Image Not Match Successfully");
            //Console.WriteLine();
        }
        public static IFaceClient Authenticate(string endpoint, string key)
        {
            return new FaceClient(new ApiKeyServiceClientCredentials(key)) { Endpoint = endpoint };
        }
        private static async Task<List<DetectedFace>> DetectFaceRecognize(IFaceClient faceClient, string url, string recognition_model)
        {
            IList<DetectedFace> detectedFaces = await faceClient.Face.DetectWithUrlAsync(url, recognitionModel: recognition_model, detectionModel: DetectionModel.Detection03, returnFaceAttributes: new List<FaceAttributeType> { FaceAttributeType.QualityForRecognition });
            List<DetectedFace> sufficientQualityFaces = new List<DetectedFace>();
            foreach (DetectedFace detectedFace in detectedFaces)
            {
                var faceQualityForRecognition = detectedFace.FaceAttributes.QualityForRecognition;
                if (faceQualityForRecognition.HasValue && (faceQualityForRecognition.Value >= QualityForRecognition.Medium))
                {
                    sufficientQualityFaces.Add(detectedFace);
                }
            }
            Console.WriteLine($"{detectedFaces.Count} face(s) with {sufficientQualityFaces.Count} having sufficient quality for recognition detected from image `{Path.GetFileName(url)}`");


            return sufficientQualityFaces.ToList();
        }
        [Route("api/FaceAttribute"), HttpPost]
        public async Task<IActionResult> FaceAttribute([FromBody] dynamic value)
        {
            string base_url = "https://testrasstorage.blob.core.windows.net/blobcontainer/" + JsonConvert.DeserializeObject<Jsonoutput1>(value.ToString()).sourceImageFileName;  
            const string recognition_model = RecognitionModel.Recognition04;
            const string SUBSCRIPTION_KEY = "5aea0303917e4cf184c0e94c8f8b474e";
            const string ENDPOINT = "https://faceapiresourcedemo20.cognitiveservices.azure.com/";
            IFaceClient faceClient = Authenticate(ENDPOINT, SUBSCRIPTION_KEY);
            var faces1 = await faceClient.Face.DetectWithUrlAsync(base_url, true, true, recognitionModel: recognition_model, returnRecognitionModel: true, returnFaceAttributes: new List<FaceAttributeType> { FaceAttributeType.Exposure, FaceAttributeType.Age, FaceAttributeType.Accessories, FaceAttributeType.Gender, FaceAttributeType.Smile, FaceAttributeType.Emotion , FaceAttributeType.Glasses});
            return Ok(faces1);
        }
    }
    public class Jsonoutput
    {
        //public int id { get; set; }
        public string sourceImageFileName { get; set; }
        public string targetImageFile { get; set; }
    }
    public class Jsonoutput1
    {
        //public int id { get; set; }
        public string sourceImageFileName { get; set; }
    }
}