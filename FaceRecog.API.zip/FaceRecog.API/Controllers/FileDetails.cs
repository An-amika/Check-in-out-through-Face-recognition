﻿using System;

namespace FACERecog.API.Controllers
{
    internal class FileDetails
    {
        public string Filename { get; set; }
        public string Content { get; set; }
        public string ContentType { get; set; }

        internal IDisposable OpenReadStream()
        {
            throw new NotImplementedException();
        }
    }
}