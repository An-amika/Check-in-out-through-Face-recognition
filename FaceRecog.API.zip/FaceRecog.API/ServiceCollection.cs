﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using FACERecog.API.Contracts;
using FACERecog.API.Domain;
using FACERecog.API.Repository;

namespace FACERecog.API
{
    public static class ServiceCollectionFACERecog
    {
        public static void AddFACERecogServices(this IServiceCollection services)
        {
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddScoped<IBaseRepository, BaseRepository>();
            services.AddScoped<IFACERecogAuthorization, FACERecogAuthorization>();
        }
    }
}
